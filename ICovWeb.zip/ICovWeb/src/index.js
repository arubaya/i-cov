import "regenerator-runtime";
import "./style/styles.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.min.js";
import "popper.js/dist/popper.min.js";
import "./script/component/app-bar.js";
import "./script/component/foot-bar.js";